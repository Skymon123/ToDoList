// To Do List and Priority List

#include <iostream>
using namespace std;
class ToDoList
{
private:
	string *array;
	int num_of_elements;
public:
	ToDoList(int size);
	void add(string item_to_add);
	void show();
	void delet(int delItem);
  void priorityL();
};
ToDoList::ToDoList(int size)
{
	array = new string[size];
	num_of_elements = 0;
}
void ToDoList::add(string item_to_add) {
	array[num_of_elements] = item_to_add;
	num_of_elements++;
}
void ToDoList::show() {
	if (num_of_elements == 0){
		cout << "\n Your To Do List is empty! \n";
		return;
	}
	if (num_of_elements == 1){
		cout << " ------------To Do List------------\n" << array[0] << " - Item 1 \n";
		return;
	}
	int i;
	cout << " ------------To Do List------------\n";
	for (i = 0; i < num_of_elements - 1; i++)
		cout << array[i] << " - Item  " << i+1 << endl;
	cout << array[i] << " - Item " << i+1 << endl;
	cout << endl;
}
void ToDoList::delet(int delItem)
{
	int del=delItem;
	del--;
	for (int i = del; i < num_of_elements; i++)
		array[i] = array[i + 1];
	num_of_elements--;
}

void ToDoList::priorityL()
{
  int pri;
  string prio[num_of_elements];
    for (int i=0; i<num_of_elements;i++)
    {
      cout << "The " << i+1 << " priority item #: ";
      cin >> pri;
      prio[i]=array[pri-1];
    }
  cout << endl;
  cout << "----Priority List----\n";
  for (int i=0;i<num_of_elements;i++)
  {
    cout << i+1 <<". " << prio[i] << endl;

  }
}

int main(){
  int totalItem;
	while(true){
    int listsize;
  	cout << "How many things you have on your to do list: ";
  	cin >> listsize;
    totalItem=0;
  	ToDoList list(listsize);
  	for (int i = 0; i < listsize; i++){
  		string item;
  		cout << "Enter list item: ";
  		cin >> item;
  		list.add(item);
      totalItem++;
  	}
  	cout << "Max Items: " << listsize << endl;
    list.show();
   if (listsize==0)
     return 0;
  	while (true){
  		string wDel;
  		cout << "Would you like to delete something(yes or no)? ";
  		cin >> wDel;
  		if (wDel == "yes"){
  			int deItem;
  			cout << "What Item # would you like to delete?: ";
  			cin >> deItem;
  			list.delet(deItem);
        totalItem--;
        cout << "Max Items: " << listsize << endl;
  			list.show();
  			continue;
  		}
  		if (wDel == "no"){
  			cout << "Max Items: " << listsize << endl;
        list.show();
  			break;
  		}
  	}
   while (true)
   {
     string wAdd;
     cout << "Would you like to add something(yes or no)? ";
     cin >> wAdd;
     if (wAdd=="yes")
     {
       string item2;
        cout << "What do you want to add: ";
        cin >> item2;
        list.add(item2);
        totalItem++;
        cout << "Max Items: " << listsize << endl;
        list.show();
        continue;
     }
      else if (wAdd=="no")
     {
       cout << "Max Items: " << listsize << endl;
       list.show();
       break;
     }
    
   }  
    string confirm;
    cout << "Do you want to 'reset' or 'keep': \n";
    list.show();
    cout << ":(reset or keep): ";
    cin >> confirm;
    if (confirm=="keep")
    { cout << endl;
      list.priorityL();
      break;
    }
    else if (confirm=="reset")
      continue;

  }
 

	return 0;
}